# Kino V1 — Hardware Build Specification

This document describes the current V1 prototype architecture. It is self-contained, but all electrical work should also use `KINO_V1_WIRING.md`.

## 1. System overview

Kino V1 is a five-MCU camera:

- **1× Guition JC4880P443C-I-W** main board with ESP32-P4, ESP32-C6, 4.3-inch 480×800 capacitive display, USB, microSD/TF slot, exposed 2×13 header, and speaker connector.
- **4× Seeed Studio XIAO ESP32-S3 Sense**, each with one **OV3660 3 MP** camera, local PSRAM/flash, JPEG capture firmware, a dedicated UART to the P4, and one shared trigger input.
- The P4 coordinates capture, renders UI, saves media, generates previews/animations, exposes the USB serial protocol, and manages updates.
- Each XIAO owns its sensor and sends completed JPEGs; the P4 does not ingest four raw DVP camera buses.

The ESP32-C6 is available for future Wi-Fi/BLE work but is not required for V1 shooting or browser-based USB configuration.

## 2. Optical assembly

```text
FRONT

        [ centered flash bar ]

   ○         ○         ○         ○
 CAM1      CAM2      CAM3      CAM4
```

- Landscape orientation, four parallel optical axes.
- Nominal lens-center pitch: **22 mm**.
- Experimental camera-bar range: **20–24 mm**.
- Nominal outer baseline at 22 mm pitch: **66 mm**.
- Main subject zone: **0.8–2.5 m**, optimized near 1–2 m.
- The four modules must be held rigidly even though the enclosure is intentionally handmade.
- Use a removable printed camera bar/cassette so pitch and alignment can be revised without rebuilding the entire body.
- Give every lens a short opaque tunnel and isolate the flash chamber completely from the sensors.

Do not finalize the camera pockets until the actual XIAO Sense assemblies are measured. Allow cable-bend clearance and roughly 1–1.5 mm separation between neighboring PCBs where practical.

## 3. Main board and user interface

The Guition board supplies:

- 4.3-inch rear touchscreen for framing, mode selection, review, playback, and gallery;
- microSD storage;
- USB connection to Kino Studio and recovery tooling;
- four hardware UARTs for the camera nodes;
- GPIO for shared trigger, camera-rail enable, flash enable, and physical controls;
- speaker output, subject to connector and amplifier verification.

Marketplace dimensions have varied. Treat approximately 114–117 × 67–69 mm as planning information only. Measure the actual PCB, screen glass, mounting holes, connector overhang, and display active area before CAD.

## 4. Power system

```text
1S 3.7 V / 3000 mAh LiPo
          │
          ▼
  1S protection/BMS board
          │ P+ / P-
          ▼
     3 A fuse on +
          │
          ▼
   SW6106 charger/boost
          │ 5 V output
          ▼
      reinforced 5 V bus
        ├── Guition P4/display
        ├── switched four-camera rail
        └── constant-current flash driver
```

### Battery

- Nominal: 1S, 3.7 V, 3000 mAh, approximately 11.1 Wh.
- Listed pouch format: 505573, approximately 55×73×5 mm.
- Three-wire PH2.0-style connector; the third wire is presumed NTC but must be measured/identified.
- Never trust wire colors or listing polarity. Map +, −, and third lead before connection.
- Mount in a rigid PETG tray with foam anti-rattle pads. Do not clamp, crease, puncture, glue across, or place the pouch against a hot board/heatsink.

### Protection and fuse

- Purchased/selected external protection: **1S 10 A BMS**.
- Final prototype fuse decision: **3 A fast fuse**.
- Standard topology is cell to BMS `B+/B-`, then protected `P+/P-` to the fuse/SW6106. Confirm the exact purchased board’s pad labels before wiring.
- The BMS current number is not permission to pull 10 A from the pouch or PH2.0 connector.
- If 3 A nuisance-trips, measure the system. Do not automatically increase fuse rating.

### SW6106 operating rules

- Used as V1 charger/5 V boost/power-bank stage.
- Leave the cell-voltage selection at **4.20 V**; do not select 4.35 V.
- Initially charge from an ordinary **5 V, approximately 1 A** USB source with the camera off.
- Do not begin with QC/PD fast charging because the cell’s charge specification is not trusted.
- Observe the pouch and SW6106 temperature during early cycles. Stop for warmth beyond expectation, swelling, odor, damage, unstable voltage, or abnormal charging.
- Bench-test whether the module can safely support use-while-charging; V1 should not promise this behavior until verified.

### Distribution

- Use **20 AWG** wire for battery-side power, SW6106 output, main 5 V/GND buses, camera rail, and LED rail.
- Do not carry camera/flash current through narrow perfboard strips or the IDC ribbon.
- The IDC can feed the Guition board only after the available 5 V/GND contacts are validated; parallel appropriate power/ground contacts where the board design permits.
- Place 1000 µF bulk capacitance near the carrier input and another 1000 µF near the camera switching bank. Add local 100 nF ceramics at control sections.

## 5. Camera power switching

Each XIAO is externally fed at its 5 V input through a dedicated branch:

```text
5 V camera bus
   → AO4407 P-channel high-side MOSFET
   → 1N5819 Schottky diode
   → PH2.0 camera harness
   → XIAO 5V
```

The four MOSFETs remain separate branch devices, but V1 may drive all four gates from one common `CAM_PWR_EN` through four 2N3904 stages. This turns the whole camera bank on/off together. Keeping separate devices makes branch diagnosis and a later per-camera power design easier.

Per branch:

- AO4407 source to +5 V; drain toward the camera branch.
- 100 kΩ gate-to-source pull-up defaults the P-MOSFET off.
- 2N3904 collector to MOSFET gate, emitter to GND.
- P4 enable to 2N3904 base through 4.7 kΩ.
- Recommended 100 kΩ base-to-GND pull-down keeps the NPN off during boot.
- 1N5819 anode toward the switched supply, cathode toward XIAO 5 V.

Verify the exact package pinout for every purchased transistor lot. Confirm that the Schottky drop still leaves adequate voltage at the XIAO during peak capture.

Operationally, cameras stay powered and initialized while the device is actively shooting. Power-gate them only after an inactivity timeout, tentatively around three minutes, because rebooting four nodes on every shutter press would ruin responsiveness.

## 6. Flash assembly

Selected light source:

- **1× 3 W natural-white RA90 LED** on star PCB; remaining LEDs are spares.
- Adjustable constant-current driver.
- Initial electrical target: **350 mA**.
- Normal experimental range after measurements: roughly **350–500 mA**.
- Only evaluate higher levels after checking exposure, cell/rail sag, LED temperature, driver temperature, and enclosure temperature. Never assume the driver’s maximum is suitable.

Thermal stack:

```text
LED star PCB
    │
0.5 mm thermal pad
    │
20×20×7 mm copper heatsink
```

Use a small 1 mm opal acrylic diffuser, approximately **25–35 mm wide × 10–15 mm high**, in a short sealed light chamber. Kino wants a punchy compact-digicam hit, not a softbox.

Current styling places the flash bar above and centered over CAM2/CAM3. Validate grip shadow, red-eye tendency, forehead clipping, internal light leakage, and thermal clearance in the PETG prototype before cutting final acrylic.

Flash sequencing:

```text
freeze/distribute exposure
→ arm cameras
→ flash on
→ short calibrated settle
→ shared trigger
→ capture confirmation
→ flash off
→ shutter sound
```

Do not play the speaker during exposure.

## 7. Storage

- **32 GB microSD**, FAT-compatible during early development.
- Guition board’s built-in slot is the primary store; no separate SD breakout is required.
- Preserve originals before generating processed images or animations.
- Use transactional writes: temporary filename, flush/close, then rename/commit metadata so power loss does not leave a valid-looking incomplete set.
- Never format or bulk-delete without strong confirmation in Studio/device UI.

Example:

```text
/DCIM/WG000001/
    C1_RAW.JPG
    C2_RAW.JPG
    C3_RAW.JPG
    C4_RAW.JPG
    C1_LOOK.JPG
    C2_LOOK.JPG
    C3_LOOK.JPG
    C4_LOOK.JPG
    WIGGLE.MP4
    META.JSON
```

Quad sets may use `QD000001` and the same four-original rule.

## 8. Speaker and physical controls

Speaker reported purchased:

- **8 Ω, 2 W, 25×35 mm (“3525”), 1.25 mm 2-pin connector**.
- Intended for shutter click, startup sound, warnings, UI beeps, and deliberately cheap-digicam processing sounds.
- Verify the Guition connector pinout and amplifier compatibility before full-volume use.
- Mount by the outer frame in a printed pocket with foam isolation and an air/grille opening. Never press the diaphragm against the shell.

Physical controls:

- shutter button;
- function button;
- SW6106 K/power control button as applicable;
- slide switch used only as a logic/mode/lock input, never as the main battery-current switch;
- touchscreen for normal settings and review.

Provide strain relief at all button and connector leads.

## 9. Carrier board

The existing perforated/perma-proto board is the internal carrier. It should contain:

- 26-pin 2×13 box header for the Guition IDC connection;
- four PH2.0 4-pin camera connectors;
- four AO4407 adapter boards;
- four 2N3904 gate drivers and resistors;
- four 1N5819 diodes;
- shared-trigger fanout resistors/connector points;
- reinforced +5 V and GND bus wires;
- two 1000 µF/10 V bulk capacitors;
- local 100 nF bypass capacitors;
- flash-control connection;
- test pads for 5 V, GND, camera rail, flash enable, trigger, and each UART.

Before soldering, map any pre-connected rows/rails on the board with continuity mode. Do not assume it is an isolated-hole perfboard.

## 10. Enclosure and serviceability

### PETG prototype

Approximate planning envelope: **126 W × 78–82 H × 34–38 D mm**. Grow it if necessary for safe bend radii, thermal gaps, and the pouch tray.

Three main assemblies:

1. Front shell with sealed flash chamber and removable camera bar.
2. Midframe with battery tray, carrier, SW6106/BMS, speaker pocket, cable paths, and heat isolation.
3. Rear bezel with Guition display and service/port access.

Use purchased M2 heat-set inserts and screws. Design 6–7 mm bosses with adequate wall thickness, then tune insert-hole diameter using a PETG test coupon rather than trusting a universal dimension.

Use 1 mm adhesive foam for:

- battery anti-rattle pads;
- speaker frame isolation;
- camera-module edge isolation;
- rear-panel contact/gasket areas;
- internal light seals.

Foam is not a primary battery restraint, heatsink mount, or PCB mount.

### Acrylic final shell

- 2–3 mm clear acrylic panels as non-structural skin.
- Black PETG skeleton takes all screw, battery, camera, PCB, and heatsink loads.
- Acrylic screws into PETG heat-set inserts; do not thread/tighten directly into brittle acrylic.
- Protect the LiPo behind an opaque printed tray/backplate.
- Keep wiring visually disciplined: red 5 V, black GND, yellow trigger/control, blue UART TX, green UART RX where possible.

## 11. Thermal and safety separation

- Do not place the pouch directly behind the LED heatsink or SW6106.
- Use PETG ribs/partitions and air gaps around hot components.
- Keep metal heatsinks away from exposed PCB pads and the cell pouch.
- Use Kapton as supplemental electrical insulation, not as the only mechanical barrier.
- Add no sealed enclosure assumptions until heat-soak testing is complete.
- Include a wrist-strap eyelet and raised screen bezel because the camera will be passed around near drinks.

## 12. Assembly and validation sequence

1. Measure every component and print a shallow fit frame.
2. Map the Guition header and validate candidate GPIOs without camera power attached.
3. Bring up one XIAO from a current-limited bench supply.
4. Prove one UART, capture, JPEG framing, CRC, and retry behavior.
5. Build and characterize one AO4407/2N3904/1N5819 branch.
6. Clone the branch to four cameras; verify off-state leakage and startup behavior.
7. Implement shared ARM/trigger and collect timing telemetry.
8. Add SD writes and power-loss-safe shot directories.
9. Add the LED at low current; test flash leakage and exposure.
10. Measure battery-side and 5 V-side current, rail sag, fuse behavior, connector and component temperature.
11. Add speaker and controls only after capture is stable.
12. Complete the PETG shell; validate it through real party-like handling before translating geometry to acrylic.
