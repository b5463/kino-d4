# Kino — Master Project Context

Snapshot date: **2026-08-14**

## One-sentence definition

**Kino is a handmade four-lens digital house-party camera whose primary output is a four-view stereoscopic wigglegram and whose character combines a disposable camera, a mid-2000s compact digicam, and an experimental DIY electronics object.**

## Why it exists

Kino is not trying to outperform a phone. It should be fun to point at friends from roughly **0.8–2.5 m**, produce an immediate flash-hit party image, and turn four horizontally separated views into a rocking 3D animation. Its limitations are part of the product:

- hard direct flash and bright faces;
- darker room backgrounds with colored ambient light;
- visible sensor noise and grain;
- limited dynamic range and occasional clipped highlights;
- slightly unreliable white balance;
- soft tiny-lens detail and crunchy JPEG sharpening;
- real differences between four inexpensive camera modules;
- visible screws, wiring, printed structure, and service seams.

The intended emotional result is closer to **“a genuinely cheap little camera that happened to take a great photo”** than **“a modern image with a disposable-camera filter.”**

## Primary and secondary modes

### Wiggle — flagship/default

Four matched views are captured as near-simultaneously as V1 permits. Exposure, gain, white balance, resolution, processing, and flash participation should match closely across all four cameras. Small per-module calibration offsets are allowed, but the system must preserve some natural character.

Playback defaults to:

```text
1 → 2 → 3 → 4 → 3 → 2 → repeat
```

The bounce avoids the hard `4 → 1` jump. Initial target is **10 fps**, adjustable roughly **5–15 fps**.

### Quad — secondary

All four cameras still fire from one shutter press, but each is intentionally assigned a different recipe or capture behavior. Example:

| Camera | Example role |
|---|---|
| CAM1 | Party Neg |
| CAM2 | Motion / short exposure |
| CAM3 | Flash Digi / blown-and-crunchy |
| CAM4 | Acros-ish monochrome |

Quad produces four independent party photographs. It does not require different firmware.

## V1 architecture

```text
                 GUITION JC4880P443C-I-W
                  ESP32-P4 + ESP32-C6
                  4.3-inch touch display
                           │
         ┌─────────────────┼─────────────────┐
         │                 │                 │
      UART 1            UART 2            UART 3            UART 4
         │                 │                 │                 │
   XIAO S3 #1        XIAO S3 #2        XIAO S3 #3        XIAO S3 #4
    + OV3660          + OV3660          + OV3660          + OV3660
         └───────────────── shared trigger ───────────────────┘
```

Each XIAO is an intelligent camera node: it owns one OV3660, captures and JPEG-encodes locally, receives configuration and arm commands, reports timing/status, and sends a finished JPEG to the P4. The P4 owns the UI, shot coordination, storage, animation/export work, settings, diagnostics, and USB connection to Kino Studio.

## Current locked design decisions

1. **Four XIAO ESP32-S3 Sense modules with OV3660 sensors** are the V1 camera heads.
2. The **Guition JC4880P443C-I-W** is the V1 main/display board.
3. Cameras sit in one rigid horizontal row with parallel optical axes.
4. Nominal V1 lens-center pitch is **22 mm**, with removable camera-bar experiments across **20–24 mm**. At 22 mm, CAM1-to-CAM4 baseline is **66 mm**.
5. Default capture is **1600×1200, 4:3 JPEG**. **2048×1536 / 3 MP** is an optional HQ mode.
6. Wiggle is the primary reason for four cameras. Quad remains a deliberate creative mode.
7. Capture first, then transfer. Four UARTs may operate in parallel where stable, but image-transfer scheduling must never delay the shared capture event.
8. All four original JPEGs are always preserved. Generated looks and animations are derivative files.
9. One universal firmware supports Wiggle, Quad, recipes, calibration, and diagnostics. Mode changes are configuration changes, not reflashes.
10. One **3 W natural-white, RA90 LED** provides a short flash-like pulse through a small opal diffuser. Start conservatively and characterize current, heat, exposure, and rail sag.
11. The latest exterior direction places a horizontal **flash bar above CAM2/CAM3**, centered over the four-lens row. Older notes showing the flash below the row are superseded for the final acrylic styling reference; a PETG test shell may remain flexible until optical tests confirm the placement.
12. The first structural enclosure is PETG. The later final enclosure is clear acrylic skin over a black PETG internal skeleton.
13. The battery pouch must be protected and visually hidden behind a black tray even in the transparent version.
14. The device stays serviceable: M2 heat-set inserts, removable camera bar, accessible USB ports, microSD access, replaceable harnesses, and no need to destroy the shell for repairs.
15. The hardware and software should feel handmade and nostalgic, not like a faux-vintage luxury product.

## Physical language

Current front reference:

```text
┌────────────────────────────────────┐
│             FLASH BAR              │
│                                    │
│    ○       ○       ○       ○       │
│   C1      C2      C3      C4       │
│                                    │
│ visible boards, wiring and hardware│
└────────────────────────────────────┘
```

Prototype external target is approximately **126 mm wide × 78–82 mm high × 34–38 mm deep**, but final CAD must follow caliper measurements of the actual Guition board, camera assemblies, battery, ports, and heatsinks. Earlier portrait-like and smaller body proposals are obsolete.

Prototype construction:

- PETG front shell, midframe, and rear bezel;
- visible print lines and exposed M2 screws;
- removable black camera bar;
- short opaque lens tunnels;
- isolated flash chamber to prevent internal flare;
- protected battery tray;
- foam only as padding, anti-rattle material, and light seal—not as a structural mount.

Future final construction:

- 2–3 mm clear acrylic front/rear/side panels;
- black PETG internal load-bearing skeleton;
- screws through acrylic into heat-set inserts in PETG;
- visible PCBs, copper heatsink, PH2.0 harnesses, and disciplined color-coded wiring;
- frosted/opal flash window;
- raised screen bezel and wrist-strap eyelet.

## House-party image target

Default shooting zone is people at **0.8–2 m**, with useful results possible around 2.5 m depending on room light. Beyond about 3 m, the single LED is only fill.

Starting image character:

- 3 MP-class OV3660 hardware, normally output at 1600×1200;
- 4:3 framing;
- direct flash;
- low denoise;
- moderate sharpening;
- slightly elevated saturation and contrast;
- no HDR, night mode, face beautification, or aggressive shadow recovery;
- allow occasional clipped skin highlights and dark corners;
- retain minor module-to-module personality without making Wiggle frames distractingly inconsistent.

Suggested look library: **Party Neg, Chrome, Superia, Velvia-ish, Acros-ish, Flash Digi, Raw Digi, Warm 2007, Cold Flash, Disposable**. These are “inspired” looks, not claims of reproducing a camera manufacturer’s exact color science.

## V1 synchronization truth

The P4 will arm all four XIAOs and pulse one shared trigger line. This can make firmware response times close, but standard OV3660 modules are free-running rolling-shutter sensors. A common GPIO pulse does not guarantee that their exposure windows begin on the same sensor row or even the same frame phase.

Therefore V1 synchronization is explicitly **experimental**. The project needs a skew bench and moving-subject tests. Do not claim microsecond exposure sync from GPIO timestamps alone. Weird motion in V1 wiggles may be part of the raw aesthetic, but timing must still be measured and improved as far as practical.

## V1 power direction

The V1 power chain is a 1S 3000 mAh LiPo, external 1S protection board, **3 A fuse**, SW6106 charger/5 V boost module, and a reinforced 5 V distribution bus. Four XIAO rails are high-side switched with AO4407 P-channel MOSFETs driven by 2N3904 transistors. Each externally fed XIAO has a series 1N5819 Schottky diode.

This is a prototype power system, not a validated consumer design. Charge at 4.20 V only, begin with an ordinary 5 V/~1 A input source, test on a current-limited bench supply first, and measure peak current, voltage sag, connector temperature, cell temperature, and fuse behavior before normal use.

## V2 direction: high-fidelity Kino

V2 is not a sensor swap. It keeps Kino’s main concepts—four camera nodes, a master controller, Wiggle/Quad modes, calibration, metadata, Studio, flash control—but replaces the imaging and transport layers.

Likely V2 characteristics:

- approximately 12 MP per camera;
- MIPI CSI-2 sensors and MIPI-capable camera processors;
- true hardware frame synchronization prioritized above autofocus;
- much faster transport such as USB High Speed or another high-bandwidth fabric;
- larger power budget and likely custom camera PCBs;
- more crop margin for geometry correction and stabilization;
- optional 3 MP “Digi” output that preserves V1-like processing.

The IMX477 family is a leading conceptual reference because multi-camera XVS synchronization is possible, but sensor choice, driver support, ISP tuning, board size, and availability must be re-researched when V2 starts. IMX708 is attractive for compact autofocus and low light, but standard camera modules may not expose the required sync signals. Fixed-focus matched lenses may be preferable to four autofocus systems that visibly breathe differently.

V1 remains the authentic dirty party camera; V2 becomes the synchronized, high-fidelity Kino rather than making V1 obsolete.

## Open validation gates

Do not close these by assumption:

- Guition 2×13 header pinout and which exposed GPIOs are safe/available;
- final UART pin routing and boot-strap interactions;
- GPIO35 behavior—leave it unused initially;
- actual battery PH2.0 polarity and third-wire/NTC behavior;
- actual BMS pad topology and whether the cell includes its own protection;
- SW6106 current limits, power-path behavior, and thermal envelope;
- 3 A fuse nuisance-trip margin under real simultaneous capture;
- AO4407 and 2N3904 package pinouts from the purchased lots;
- camera 5 V voltage after the 1N5819 drop;
- LED driver enable/control polarity and safe current range;
- true exposure skew and rolling-shutter behavior across the four OV3660s;
- mechanical dimensions, optical-axis alignment, and flash-to-lens light isolation.

## Recommended build sequence

```text
measure all parts
→ validate P4 pins/header
→ power one XIAO from bench supply
→ prove one UART protocol
→ capture one JPEG
→ build/validate one high-side switch
→ expand to four UART nodes
→ implement ARM + shared trigger
→ measure timing/skew
→ save four JPEGs to microSD
→ add flash at low current
→ measure rail sag and heat
→ create Wiggle playback
→ print fit frame
→ print PETG prototype shell
→ only later translate proven geometry to acrylic
```
