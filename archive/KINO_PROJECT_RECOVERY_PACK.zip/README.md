# Kino Project Recovery Pack

Snapshot date: **2026-08-14**  
Source context: ChatGPT task **“Camera Name Identification”** (`6a7b0e55-06f4-83eb-a8d4-baf5f1f2b088`)

This folder is the portable context pack for **Kino**, a handmade four-lens digital party camera. Upload the files to a future chat when the original conversation is unavailable or has fallen out of context.

## Recommended upload order

For a full restore, upload **all seven Markdown files together**. If the interface requires one at a time, use this order:

1. `KINO_MASTER_CONTEXT.md` — intent, identity, locked decisions, V1/V2 direction.
2. `KINO_PARTS_LIST.md` — what was selected, bought, owned, removed, or deferred.
3. `KINO_V1_HARDWARE_BUILD.md` — physical and electrical architecture.
4. `KINO_V1_WIRING.md` — detailed interconnect and provisional pin plan.
5. `KINO_FIRMWARE_AND_CAPTURE.md` — modes, timing, image behavior, storage, metadata.
6. `KINO_STUDIO_SPEC.md` — browser application, protocol, updater, gallery, diagnostics.
7. This `README.md` — provenance and interpretation rules.

If upload space is limited, start with the master context plus whichever specialist file matches the next task. For electrical work, always upload both the hardware-build and wiring files.

## Important interpretation rules

- This is a **design snapshot**, not proof that the hardware has been assembled or validated.
- “Locked” means it is the latest project decision, not that it is electrically certified.
- GPIO assignments, Guition header functions, battery polarity, transistor pinouts, LED-driver behavior, current draw, thermal behavior, and sensor timing must be verified on the actual parts before permanent soldering.
- The latest decisions supersede earlier ideas: Wiggle is the primary mode; Quad is secondary; the current aesthetic reference has the flash bar **above** the lens row; the V1 lens pitch target is **22 mm nominal, adjustable 20–24 mm**.
- A shared trigger line improves command simultaneity but does **not** prove exposure-level synchronization of four free-running OV3660 sensors.
- LiPo work is safety-critical. Use current-limited bench testing first, confirm polarity, keep the cell mechanically protected, and do not substitute a larger fuse merely because the chosen fuse nuisance-trips.

## File map

| File | Scope |
|---|---|
| `KINO_MASTER_CONTEXT.md` | Product brief and decision ledger |
| `KINO_V1_HARDWARE_BUILD.md` | Complete V1 build architecture and assembly order |
| `KINO_V1_WIRING.md` | Power, UART, trigger, IDC, switching, wire gauges, validation |
| `KINO_PARTS_LIST.md` | BOM and purchase-status ledger |
| `KINO_FIRMWARE_AND_CAPTURE.md` | Five-MCU firmware, Wiggle/Quad behavior, storage and V2 path |
| `KINO_STUDIO_SPEC.md` | Web Serial configuration/updater/gallery/diagnostic application |

The ZIP beside these files is only a convenience copy; the Markdown files are the source of truth.
