# Kino V1 — Wiring and Interconnect Specification

**Status:** engineering plan, not a validated schematic. Verify the actual Guition board, purchased modules, connector polarity, and semiconductor pinouts before permanent soldering.

## 1. Grounding and power topology

All logic uses a common ground. Use a reinforced star/tree-like distribution from the SW6106 output rather than sending camera or flash current through the Guition header.

```text
LiPo cell
  B+ ─────────────────────────────┐
  B- ──────────────────────────┐  │
                               ▼  ▼
                         1S BMS B-/B+
                         1S BMS P-/P+
                               │  │
                               │  └── 3 A fast fuse
                               │          │
                               └──────────┼── SW6106 BAT-/BAT+
                                          │
                                    SW6106 5 V OUT
                                          │
                           20 AWG +5 V / GND trunks
                     ┌────────────────────┼────────────────────┐
                     │                    │                    │
               P4/display feed      camera switch bank     LED driver
```

The exact BMS pad names/topology must match its datasheet or silkscreen. If the LiPo already contains protection, document how the external BMS interacts with it rather than bypassing either casually.

### Battery connector

The cell has a 3-pin PH2.0-style plug. Identify the pins by measurement:

```text
Pin ?  cell +
Pin ?  cell -
Pin ?  presumed NTC/sense
```

The presumed NTC lead remains insulated until a proper bias circuit and ADC input are designed. Never connect it directly to an arbitrary voltage.

### Required power measurements

Record at minimum:

- battery idle and capture voltage;
- SW6106 5 V rail idle and capture voltage;
- peak battery-side current;
- peak 5 V-side current;
- PH2.0 and splice temperature;
- SW6106, BMS, fuse, MOSFET, diode, LED driver, heatsink, and cell temperature;
- reset/brownout count during capture/flash.

## 2. P4-to-carrier IDC

Physical chain:

```text
Guition 2×13 male header
        ↓
26-pin female IDC connector
        ↓ ribbon
26-pin female IDC connector
        ↓
2×13 male keyed box header on carrier
```

Rules:

- Mark pin 1 at both ends permanently.
- The Guition end may not be mechanically keyed; verify orientation by continuity before power.
- Create a documented table mapping physical IDC positions to Guition labels and tested ESP32-P4 GPIOs.
- Never infer odd/even numbering from a photograph.
- Keep camera/LED branch current off the ribbon.
- If the P4 is powered over the IDC, use only confirmed 5 V inputs and parallel confirmed ground/power contacts where supported. Do not backfeed a USB rail without understanding the board’s power ORing.

## 3. Camera connectors and UARTs

Each camera uses one **PH2.0 4-pin** harness:

| Pin | Signal | Direction |
|---:|---|---|
| 1 | +5 V switched, after 1N5819 | Carrier → XIAO 5V |
| 2 | GND | Common |
| 3 | P4 TX | P4 → XIAO RX |
| 4 | P4 RX | XIAO TX → P4 |

TX and RX must cross. Signaling is **3.3 V UART**; no level shifter is planned.

The shared trigger is a separate fifth conductor to each XIAO because the 4-pin camera harness is already full. Route it as 28 AWG signal wire or revise the connector in a future carrier revision.

Starting UART rate: **921,600 baud**. After signal-integrity and framing tests, evaluate approximately **1.5–3 Mbaud**. Use short harnesses, common ground, binary framing, chunk CRCs, timeouts, and retries. Do not raise baud merely because a short bench wire worked once.

Four dedicated UARTs allow parallel receiving, but SD and buffer availability may favor staggered/chunked transfers. The invariant is:

```text
simultaneous/near-simultaneous capture
≠
required simultaneous transfer
```

## 4. Shared trigger

```text
P4 SYNC_TRIGGER
       │
       ├── 1 kΩ ── XIAO1 trigger input
       ├── 1 kΩ ── XIAO2 trigger input
       ├── 1 kΩ ── XIAO3 trigger input
       └── 1 kΩ ── XIAO4 trigger input
```

Candidate XIAO input: **D0 / GPIO1**, pending verification against the actual Sense camera pin use and boot behavior.

Firmware sequence:

```text
P4 sends ARM to all four UARTs
→ each node freezes/applies exposure settings
→ each reports ARMED with timestamp/state
→ P4 enables flash and waits calibrated settle time
→ P4 produces one clean trigger edge/pulse
→ each XIAO records ISR time and begins capture request
→ each reports capture/VSYNC/JPEG timing if observable
```

The four 1 kΩ resistors isolate node inputs and limit fault current. Add defined pull-down or pull-up behavior as required so no floating boot pulse creates a photograph.

## 5. Synchronization and VSYNC caveat

The shared trigger aligns a software interrupt/request. It does **not** establish common sensor clock or frame phase. The OV3660s can remain on different positions in their free-running rolling-shutter cycles.

Consequences:

- GPIO ISR skew may look excellent while exposure skew remains poor.
- A subject moving across the frame may bend differently in each view.
- Flash may illuminate different fractions of different rolling frames if timing is wrong.
- UART `ARMED` timestamps do not prove matched exposure start.

Validation must use a skew bench: high-speed moving edge, rapidly blinking LED/timecode, oscilloscope/logic analyzer access to trigger and any observable VSYNC/frame signals, plus real moving faces/hands. If XIAO/OV3660 VSYNC can be safely observed without disrupting the camera bus, log it; do not assume a supported sensor-sync input exists.

Treat exposure-level sync as an empirical result. True hardware frame sync is a V2 requirement.

## 6. Per-camera high-side switch

One branch:

```text
                         +5 V CAMERA BUS
                                │
                                ├──────────────┐
                                │              │
                         AO4407 source       100 kΩ
                                │              │
                         AO4407 drain          └── gate
                                │                  │
                         1N5819 anode          collector
                                │               2N3904
                         1N5819 cathode          emitter
                                │                  │
                         XIAO 5V via PH2           GND

P4 CAM_PWR_EN ── 4.7 kΩ ── 2N3904 base
                              │
                            100 kΩ
                              │
                             GND
```

Logical behavior:

- P4 LOW/unconfigured → NPN off → MOSFET gate pulled to +5 V → camera off.
- P4 HIGH → NPN sinks MOSFET gate → P-MOSFET on → camera powered.

There are four copies. One P4 enable may fan out to the four 4.7 kΩ base resistors. Do not use one base resistor for four transistors.

Confirm:

- AO4407 source/drain/gate pins on the SOP8 adapter;
- 2N3904 E/B/C order for the purchased package;
- off-state gate voltage and leakage;
- MOSFET `VGS` stays within rating;
- XIAO 5 V voltage under capture load after diode drop;
- external USB connection cannot dangerously backfeed the switched rail.

Never connect a XIAO USB cable while externally powering its 5 V pin until the diode/backfeed behavior is verified for the exact wiring.

## 7. Capacitors and buses

```text
SW6106 5 V output
       │
       ├── 1000 µF / 10 V to GND near carrier input
       │
       ├── P4/display branch
       │
       ├── camera switch bank
       │      └── 1000 µF / 10 V to GND near switches
       │
       └── LED driver branch
```

- Observe electrolytic polarity.
- 100 nF ceramic capacitors belong close to switching/control circuitry, not at the end of long wires.
- Bulk capacitance is not a substitute for a boost converter and cell capable of supplying the load.
- Keep +5 V and GND trunks short and paired where possible to reduce loop area.

## 8. Flash driver connection

Power path:

```text
5 V bus → constant-current LED driver → 3 W LED star → driver return/GND
```

Control path depends on the purchased driver:

- If it exposes a logic-compatible enable/PWM pin, drive it through an appropriate pull resistor/level interface after verifying polarity and voltage limits.
- If it has no suitable enable, use a properly rated high-side or low-side switch designed around the driver input/output behavior.
- Do not drive LED current directly from a P4 GPIO.
- Do not assume another AO4407/2N3904 channel is correct until the driver topology is known.

Provisional `FLASH_EN` from the P4 is a logic signal only. Default it off with a hardware pull resistor. Provide test pads for `FLASH_EN`, driver input voltage, and LED current measurement.

## 9. Speaker and controls

Speaker:

```text
Guition speaker output → verified 1.25 mm 2P pigtail → 8 Ω / 2 W speaker
```

Verify connector polarity/pinout and amplifier suitability. Start at minimum volume.

Buttons should be logic inputs with defined pulls and software debounce. The shutter is fixed; function and slide-switch behavior are configurable. The slide switch must not interrupt the multi-amp battery path.

## 10. Provisional P4 GPIO map

This map is the latest consolidated candidate from the prior design work. It is **not approved for soldering** until continuity, boot, peripheral conflicts, voltage behavior, and firmware access are tested on the exact Guition board.

| Function | Provisional P4 GPIO |
|---|---:|
| CAM1 TX | GPIO52 |
| CAM1 RX | GPIO51 |
| CAM2 TX | GPIO50 |
| CAM2 RX | GPIO49 |
| CAM3 TX | GPIO34 |
| CAM3 RX | GPIO33 |
| CAM4 TX | GPIO30 |
| CAM4 RX | GPIO29 |
| SYNC_TRIGGER | GPIO32 |
| CAM_PWR_EN | GPIO31 |
| FLASH_EN | GPIO28 |
| SHUTTER | exposed spare or repurposed I²C-class pin after validation |

**Leave GPIO35 unused initially.** It has been identified in the project history as a boot-strapping concern; no attached peripheral should pull it into the wrong state during reset.

Earlier provisional maps used GPIO35 and assigned different functions to GPIO31/33/28. Those maps are superseded. The whole table remains provisional until hardware validation.

## 11. Recommended wire colors and gauges

| Use | Gauge | Preferred color |
|---|---|---|
| Battery/boost/main 5 V buses | 20 AWG | Red |
| Main grounds | 20 AWG | Black |
| Camera branch power in PH harness | purchased harness; minimize length | Red/Black |
| UART P4 TX | 28 AWG | Blue |
| UART P4 RX | 28 AWG | Green |
| Shared trigger/control | 28 AWG | Yellow |
| Button/sense lines | 28 AWG | other documented color |

Label both ends of all four camera harnesses. Record logical camera identity separately from physical connector position because Studio calibration may remap left-to-right order.

## 12. Pre-power checklist

1. Photograph and document every board side and connector orientation.
2. Verify no swelling or damage to the pouch.
3. Map battery pins without connecting the system.
4. Verify BMS pad labels and continuity behavior.
5. Confirm 3 A fuse placement on protected positive output.
6. Check no short exists between +5 V and GND.
7. Map IDC pin 1 and every used signal end-to-end.
8. Verify transistor/diode/electrolytic polarity.
9. Test each camera branch from a current-limited 5 V bench supply with the LiPo absent.
10. Confirm camera-off state during P4 reset/unpowered state.
11. Confirm flash defaults off.
12. Bring up P4, then one camera, then four cameras, then flash—never everything on the first power-up.

## 13. Acceptance tests before enclosure use

- 30 repeated cold boots with no unintended flash or camera latch-up.
- 100 camera-bank on/off cycles.
- 100 four-camera captures without UART framing failure.
- Capture with flash at minimum and intended current while logging both rails.
- Verify no fuse trip or unacceptable connector/diode/MOSFET heating.
- Charge/discharge observation at conservative current.
- USB connection/backfeed test for P4 and every XIAO service case.
- Trigger/VSYNC/skew measurements and moving-subject wiggle review.
- Ten-minute active shooting heat soak, followed by longer realistic party-use testing.
