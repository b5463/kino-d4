# Kino V1 — Parts List and Purchase Ledger

Snapshot date: **2026-08-14**

Status language in this file reflects the prior conversation, not a physical inventory performed today. “Purchased/selected/on the way” means the user indicated the core order was placed or ready and later explicitly confirmed buying the heat-set hardware, foam, and speaker. Recount every package when it arrives.

## 1. Core electronics

| Qty needed | Part | Selected variant/specification | Status and compatibility notes |
|---:|---|---|---|
| 1 | Guition main/display board | **JC4880P443C-I-W**, ESP32-P4 + ESP32-C6, 4.3-inch 480×800 capacitive display, microSD/TF, USB, 2×13 header, speaker connector | Purchased/selected. Measure actual PCB and verify header pinout. Similar Guition variants are not interchangeable by name alone. |
| 4 | Seeed XIAO ESP32-S3 Sense | Current camera version with **OV3660**, 8 MB-class PSRAM/flash platform | Purchased/selected as one 1-pack plus one 3-pack. Confirm all four actually contain OV3660 rather than older OV2640 stock. |
| 1 | Existing carrier board | Perma-proto/perforated board large enough for IDC, switches, connectors, caps, and buses | Already owned. Map its pre-connected holes/rails before layout. |
| 1 | microSD card | **32 GB SanDisk** or selected equivalent | Purchased/selected. No separate SD breakout required because Guition has a slot. |

## 2. Battery, charging, and main power

| Qty needed | Part | Selected variant/specification | Status and compatibility notes |
|---:|---|---|---|
| 1 | LiPo pouch | **1S 3.7 V, 3000 mAh, 505573**, three-wire PH2.0-style lead | Purchased/selected. Approx. 55×73×5 mm; third lead presumed NTC. Verify polarity and cell condition. |
| 1 | SW6106 module | **18 W** charger/5 V boost/power-bank board | Purchased/selected. Keep 4.20 V configuration; start charging from 5 V/~1 A, no QC/PD initially. |
| 1 | External protection board | **1S 10 A BMS** | Purchased/selected. 7.5 A had been preferred, but 10 A accepted. This rating does not make the cell/connector a 10 A system. |
| 1 | Main fuse | **3 A fast fuse** | Final decision. Earlier cart used 5 A; 3 A supersedes it. Measure before changing rating if it nuisance-trips. |
| as needed | Power wire | **20 AWG silicone**, red/black | Purchased/selected. Use for battery/boost/bus/high-current paths. |
| as needed | Signal wire | **28 AWG** stranded | Purchased/selected. Use for UART, trigger, buttons, enables. |
| 1 | Battery mating harness | **PH2.0 3P** | Purchased/selected. Transition to 20 AWG immediately after the short mating pigtail. |
| ≥4 pairs | Camera harnesses | **PH2.0 4P**, prewired | Purchased/selected. Each carries 5 V, GND, UART TX, UART RX. Shared trigger is separate. |

## 3. Camera switching and carrier components

| Qty needed | Part | Selected variant/specification | Status and notes |
|---:|---|---|---|
| 4 + spares | P-channel MOSFET | **AO4407**, SOP-8 | Purchased/selected. Verify the actual pinout and authenticity; mount on adapters. |
| 4 + spares | SOP-8 adapter | SOP8-to-2.54 mm breakout | Purchased/selected. Ensure copper/current path is adequate. |
| 4 + spares | NPN transistor | **2N3904** | Purchased/selected. Verify E/B/C order for the supplied package. |
| 4 + spares | Schottky diode | **1N5819** | Purchased/selected. Required on external XIAO 5 V feeds; anode supply, cathode XIAO. |
| 1 assortment | Resistors | Includes **4.7 kΩ, 1 kΩ, 100 kΩ** | Purchased/selected. Used for NPN bases, trigger isolation, MOSFET pull-ups, base pull-downs. |
| 2 | Bulk capacitor | **1000 µF / 10 V** radial electrolytic | Purchased/selected. One main bus, one camera rail; observe polarity. |
| several | Bypass capacitor | **100 nF (0.1 µF / 104)** ceramic, through-hole | Purchased/selected, listing package was large. Use locally at control circuitry. |
| 1 | IDC ribbon assembly | **26-pin female-to-female** | Purchased/selected. Mark pin 1 and verify orientation. |
| 1 | Carrier header | **2×13 / 26-pin male box header** | Purchased/selected. Fits carrier side of IDC. |

## 4. Flash and thermal parts

| Qty used | Part | Selected variant/specification | Status and notes |
|---:|---|---|---|
| 1 | LED | **3 W natural-white, RA90**, star board | Purchased/selected; listing pack appears to contain about 10. Use one, retain spares. Natural white supersedes pure-white selection. |
| 1 | Constant-current driver | Adjustable LED driver | Purchased/selected; package appears to contain multiple drivers. Begin near 350 mA and validate topology/enable behavior. |
| 1 + 1 spare | Copper heatsink | **20×20×7 mm** | Purchased/selected, quantity two. One for LED; second reserved for thermal findings such as SW6106. |
| 1 piece | Thermal pad | **0.5 mm, nominal 6 W/m·K** | Purchased/selected. Between LED star and copper heatsink as appropriate. |
| 1 small window | Opal acrylic | **1 mm** sheet | Purchased/selected. Cut roughly 25–35 × 10–15 mm after flash tests. |
| as needed | Kapton tape | Electrical/thermal-area insulation | Purchased/selected. Supplemental insulation only. |

## 5. Controls, audio, and mechanics

| Qty needed | Part | Selected variant/specification | Status and notes |
|---:|---|---|---|
| several | Tactile buttons | Through-hole/selected package | Purchased/selected. Shutter, function, SW6106 K/power as applicable. |
| ≥1 | Slide switch | **MSK-22D14** or selected equivalent | Purchased/selected. Logic only; not a battery-current switch. |
| 1 | Speaker | **3525 / 25×35 mm, 8 Ω, 2 W, 1.25 mm 2P lead** | Explicitly reported bought. Verify Guition amplifier/connector before use. |
| 1 kit | M2 heat-set inserts and screws | **M2A / Cross Head Bolt 2A**, roughly M2×5/6/7/8/10 plus ~3.2 mm OD inserts | Explicitly reported bought. Tune insert holes with a PETG test coupon. |
| 1 sheet | Adhesive foam | **1 mm black EVA/foam sheet tape** | Explicitly reported bought. Anti-rattle and light sealing, not structural restraint. |
| as needed | PETG filament | Prototype chassis/internal skeleton | Already owned. Visible print lines are intentional. |
| later | Clear acrylic | **2–3 mm** shell panels; 1 mm opal only for diffuser | Future final shell, not required to prove V1. |

## 6. Tools and workshop items reported already owned

- 3D printer and PETG filament;
- temperature-controlled soldering iron;
- electronics solder, flux, and solder wick;
- multimeter with continuity and diode test;
- digital calipers;
- USB-C data cables;
- heat gun/hot-air source;
- adjustable current-limited bench supply, approximately 5 V and 3–5 A capability;
- wire stripper, flush cutters, needle-nose pliers;
- heat-shrink tubing;
- cable ties;
- some M2 machine screws.

## 7. Deliberately removed, skipped, or deferred

| Item | Decision | Reason/current replacement |
|---|---|---|
| Extra heat-shrink kit | Removed | Already owned. |
| KF128 screw terminals | Removed | Direct reinforced 20 AWG bus wiring saves space; no need for bulky terminal block. |
| M2 nylon standoff kit | Removed | Printed PETG spacers/bosses; heat-set kit later re-added. |
| Foam tape | Initially removed, later re-added and bought | It became useful for light sealing and anti-rattle. |
| PH2.0 2P harness set | Removed as dedicated purchase | A spare pair from multi-pin harness stock can be repurposed if suitable; otherwise add only when assembly proves a need. |
| 0.5 A per-camera PPTCs | Removed | OV3660/XIAO peak behavior could nuisance-trip them; main fuse and switched branches retained. |
| 100 µF ×100 electrolytic pack | Removed | 1000 µF bulk caps plus local 100 nF retained. Add local bulk only if measurements justify it. |
| Giant male/female header assortment | Removed | XIAO-supplied/small header stock should suffice. |
| Extra 5×7 cm perfboard | Removed | Existing carrier board accepted. |
| XT30 battery connector | Skipped | User chose to keep the battery’s existing PH2.0 once, with an immediate transition to short 20 AWG wiring. |
| Separate BQ25185/BQ24074 charger board | Skipped for budget | SW6106 retained, with conservative 5 V/~1 A input and camera-off charging until tested. |
| TP4056-style charger/boost | Rejected | No trusted power-path/load-sharing behavior for the intended use. |
| 4.35 V charge setting | Forbidden | Selected pouch is treated as a normal 4.20 V cell. |
| Larger/faster charger use | Deferred | Unknown cell charge specification. |
| RTC, GPS, extra sensors | Skipped | Do not improve the core wigglegram. |
| Second flash, large diffuser, vibration motor | Skipped | Extra power/space/complexity and wrong aesthetic. |
| USB panel extensions | Skipped initially | Place actual board sockets at shell openings. |
| Larger battery | Skipped | Prove power/thermal behavior before expanding the pack. |

## 8. Critical compatibility checks on arrival

1. Confirm all four XIAO Sense modules use OV3660.
2. Confirm the exact Guition suffix `JC4880P443C-I-W`, header labels, USB roles, microSD, and speaker connector.
3. Measure LiPo connector polarity and investigate the third wire.
4. Identify whether the pouch already contains a protection board.
5. Confirm external BMS pad labels and protection behavior.
6. Confirm SW6106 4.20 V configuration and measure its behavior with a current-limited source.
7. Verify AO4407, 2N3904, 1N5819, and electrolytic orientation.
8. Inspect PH2.0 wire gauge and connector quality; replace any hot or loose connection rather than relying on nominal connector names.
9. Check LED driver input range, output-current adjustment, and enable behavior.
10. Measure every component before enclosure CAD.

## 9. Do not buy speculatively

The prior conclusion was that the core V1 build is covered. New purchases should respond to measurements or a discovered physical need—such as a different connector, safer charger, proper sensor-sync hardware, or revised fuse—not feature creep.
