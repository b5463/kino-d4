# Kino Studio — Browser Application Specification

## 1. Purpose

Kino Studio is the companion web application for configuring, calibrating, diagnosing, browsing, backing up, and updating Kino over USB. It should run locally in a supported Chromium-class browser through **Web Serial**, require no cloud account, and never require a firmware reflash merely to change Wiggle/Quad modes or looks.

The product should feel like a warm, playful **2000s MSN Messenger / Windows XP-era camera utility** rebuilt with modern reliability and accessibility: chunky panels, friendly status icons, glossy/soft gradients, pixel-art touches, familiar “wizard” flows, and reassuring sounds/animations. It must not reproduce obsolete usability: keyboard support, readable contrast, scalable type, clear errors, and reduced-motion support remain mandatory.

## 2. Runtime constraints

- Serve from HTTPS or localhost because Web Serial requires a secure context.
- Connection requires a user gesture and browser permission.
- Detect unsupported browsers and provide precise instructions rather than a broken Connect button.
- Prefer a local-first/PWA-capable static application; no account or remote backend is required for core use.
- Keep firmware packages, backups, photos, and looks on the user’s computer/camera unless the user explicitly exports them elsewhere.

## 3. Information architecture

Primary sections:

1. **Home** — connect, device summary, battery/storage, last shot, quick actions.
2. **Shoot** — resolution, preview source/quality, flash, shutter sound, review duration.
3. **Wiggle** — speed, direction, sequence, crop, preview, alignment, timing.
4. **Quad** — four camera columns, independent recipes, saved Quad sets.
5. **Looks** — browser, editor, preview, install/export.
6. **Calibration** — sensor matching, geometry, camera order, spacing, flash.
7. **Gallery** — paginated media, downloads, rendering, delete/favorite.
8. **Device** — hardware/firmware/capabilities, battery, storage, power and UART diagnostics.
9. **Updates** — unified firmware update and release notes.
10. **Recovery** — bootloader/recovery instructions and component-level repair.
11. **Backup & Restore** — versioned configuration package and selective restore.
12. **Developer** — protocol console, skew bench, raw logs, nightly firmware, factory tests.

Normal users see one camera, not five unrelated boards. Advanced details expand when needed.

## 4. Connection and capability negotiation

Connection sequence:

```text
user clicks Connect
→ browser requests serial port
→ Studio opens conservative baud/settings
→ HELLO request with Studio version and supported protocol range
→ P4 returns identity, protocol, schemas, hardware revision and capabilities
→ Studio checks compatibility
→ P4 enumerates four camera nodes and health
→ Studio loads only supported controls/pages
```

Example logical response:

```json
{
  "product": "kino",
  "deviceId": "KINO-WG001",
  "hardwareRevision": "v1-proto",
  "firmware": {"p4": "0.6.1", "c6": "0.6.1"},
  "protocolVersion": 3,
  "protocolMin": 2,
  "configSchemaVersion": 4,
  "metadataSchemaVersion": 2,
  "capabilities": [
    "mode.wiggle", "mode.quad", "camera.count.4",
    "gallery.cursor", "update.camera-proxy", "diagnostics.skew"
  ],
  "limits": {"maxLooks": 50, "maxGalleryPage": 100, "maxChunk": 65536},
  "cameras": []
}
```

Capability negotiation must drive UI. Never infer a feature only from firmware version. Unknown capabilities are ignored; required missing capabilities produce an understandable compatibility notice.

## 5. Serial protocol

Use a framed binary protocol, not newline-delimited base64 for photographs.

Frame concept:

```text
magic | protocol | type | flags | requestId | payloadLength | headerCRC | payload | payloadCRC
```

Requirements:

- request/response IDs and asynchronous events;
- explicit device/node/capture IDs;
- bounded payload lengths;
- CRC/checksum validation;
- timeouts, cancellation, retry, and clean reconnect;
- binary chunks for JPEG, firmware, backup, and logs;
- progress events independent of final results;
- protocol error codes with user-facing translations;
- flow control/backpressure so the browser cannot exhaust P4 memory;
- resume offset and checksum for large downloads/uploads where practical.

Control payloads may be JSON during early development for inspectability, then CBOR/fixed structures if performance requires it. File bytes must remain binary.

## 6. Configuration and schema versioning

Configuration is versioned independently from firmware:

```json
{
  "product": "kino",
  "hardwareFamily": "v1",
  "configSchemaVersion": 4,
  "createdBy": "kino-studio/0.8.0",
  "sections": {
    "shoot": {},
    "wiggle": {},
    "quad": {},
    "calibration": {},
    "looks": {},
    "devicePreferences": {}
  }
}
```

Rules:

- P4 is authoritative for current active configuration and validation limits.
- Studio validates before sending; P4 validates again before committing.
- Updates use patch/transaction semantics: stage, validate, commit, return normalized config.
- Every schema bump includes migration functions and release tests.
- Backups preserve unknown fields so an older Studio does not destructively strip future settings.
- Downgrade/restore never silently writes a newer schema to older firmware.
- Calibration has its own revision/checksum and records the hardware/node IDs it belongs to.

## 7. Home and device health

Home should show:

```text
Kino WG001 — READY
Battery 78%     SD 21.9 GB free

CAM1 READY   CAM2 READY   CAM3 READY   CAM4 READY

[Open Gallery] [Configure Wiggle] [Update Kino]
```

Per-camera health states:

- Ready;
- Booting;
- Offline;
- Sensor missing;
- UART error;
- Capture error;
- Firmware mismatch;
- Calibration required.

Device details include main-board revision, chip/PSRAM/flash details, uptime, reset reason, P4/C6 versions, four camera versions/sensors/PSRAM, UART statistics, capture count, and temperatures only where actually measured.

## 8. Shoot, Wiggle, and Quad

Shoot page:

- 1600×1200 default / 2048×1536 HQ;
- friendly JPEG quality levels plus numerical developer setting;
- Flash Auto/On/Off;
- CAM1–CAM4 preview selector, default CAM2;
- Low/Normal/High preview quality;
- shutter sound volume/choice;
- post-shot review Off/1/2/3 seconds/Hold.

Wiggle page:

- sequence `1-2-3-4-3-2` default;
- 5–15 fps, 10 default;
- bounce/continuous/one sweep;
- direction;
- preserve/auto-overlap/custom crop;
- play/pause, per-frame scrub, reverse, raw/processed comparison;
- automatic/manual X/Y/rotation geometry correction;
- animated preview and MP4/WebP/GIF/contact-sheet/ZIP export.

Quad page:

- one column per camera;
- independent recipe, exposure bias, gain limit, WB, contrast, saturation, sharpness, denoise, flash participation;
- named sets such as Party Four, Film Four, Chaos, Raw Four;
- 2×2 review and bulk download.

## 9. Looks

Look browser fields: thumbnail, name, description, creator, revision, favorite, installed state. Filters include Color, B&W, Party, Flash, Soft, High Contrast, Experimental, and User.

Editor groups:

- Capture: exposure bias, gain, denoise, sharpness, sensor color controls.
- Tone: black/white point, contrast, gamma, highlights, shadows, curve.
- Color: temperature, tint, saturation, RGB/matrix.
- Character: grain, vignette, bloom, halation approximation, chromatic offset, JPEG degradation.

Preview against a connected-camera image, built-in sample, or local file. Install looks without firmware updates. Export a shareable `.kino-look` or JSON package with schema, ID, revision, checksum, and compatibility declaration. Target capacity is roughly 20–50 camera-installed profiles, reported through capabilities rather than hard-coded in Studio.

## 10. Calibration

### Sensor matching

Wizard: aim at an evenly lit neutral surface, capture four frames, estimate brightness and RGB offsets, show the proposed corrections, let the user accept/edit, save a versioned calibration. Do not force mathematical identity.

### Geometry

Estimate per-camera X/Y shift, tiny rotation, common crop, and optionally lens distortion. Correct mounting error while retaining parallax. Always show overlays and before/after.

### Camera order

Identify physical leftmost through rightmost cameras one at a time and map their node IDs to CAM1–CAM4. This prevents reversed wiggles after rewiring.

### Lens spacing

Store measured optical center positions, e.g. 0.0, 22.1, 44.0, 66.2 mm, with measurement confidence/notes.

### Flash

Configure Low/Medium/High, pre-flash settle, duration, Auto threshold, and target-distance preset. A guided 1.5 m exposure test should report per-camera clipping and recommend a conservative setting.

## 11. Skew bench and timing diagnostics

Developer Skew Bench is a first-class requirement because V1 does not have guaranteed sensor sync.

It should:

- run repeated arm/trigger/capture cycles;
- collect P4 trigger timestamp, each XIAO ISR timestamp, observable VSYNC/frame timestamp, capture completion, JPEG completion, transfer start/end;
- calculate min/median/p95/max and outliers over many shots;
- distinguish command/ISR skew from exposure/frame skew;
- export CSV/JSON with firmware versions and configuration;
- show a timeline and four-camera distribution;
- guide optical tests using a blinking LED/timecode or moving edge;
- flag missing/unreliable sensor timestamps rather than inventing precision.

Example:

```text
Trigger command skew:   0.21 ms p95
Frame/exposure skew:    unavailable — VSYNC not instrumented
Encode spread:          18.4 ms
Transfer total:         9.7 s
```

## 12. General diagnostics

Expose:

- camera presence/sensor ID/firmware and last error;
- UART bytes, CRC failures, retries, timeouts, overruns, baud;
- P4 reset reason, heap/PSRAM/storage state;
- battery voltage, estimated percentage, charge state where available;
- camera rail and flash state;
- pre-shot/during-shot voltage sag;
- capture, encode, transfer, and SD-write timing;
- flash tests and per-camera clipping;
- filesystem check and recent incomplete captures;
- downloadable diagnostic bundle with sensitive data minimized.

Never display a sensor/temperature/current value the hardware cannot actually measure. Mark estimated values clearly.

## 13. Gallery and pagination

The camera may contain thousands of files; Studio must never request the whole gallery index in one response.

Use cursor-based pagination:

```json
{
  "op": "gallery.list",
  "limit": 50,
  "cursor": "opaque-token",
  "filters": {"mode": "wiggle"},
  "sort": "newest"
}
```

Response includes items, an opaque `nextCursor`, and optional approximate totals. Cursors are opaque and invalidated cleanly when the underlying index changes.

Views/filters:

- grid, Wiggles, Quad sets, individual images;
- newest/oldest, mode, recipe, favorite;
- lightweight thumbnails first, full bytes on demand.

Transfers:

- one original, complete original set, rendered animation, metadata, contact sheet, or ZIP;
- chunked binary transfer with size/checksum/progress;
- cancel and resume by stable file ID + offset where practical;
- deletion is explicit and preferably uses trash before permanent erase;
- format card requires typed/strong confirmation.

## 14. Backup and restore

`Back Up Camera` creates a `.kino` package containing:

- manifest and schema versions;
- device settings and UI preferences;
- camera order and calibration;
- Wiggle/Quad profiles;
- installed/user looks;
- flash calibration and button mapping;
- checksums and source hardware/device IDs.

Photos are excluded unless explicitly selected. Restore modes: Full, Calibration only, Looks only, Modes only, Device preferences, Flash settings. Studio previews changes and compatibility before commit.

## 15. Firmware packages and unified update flow

Release package:

```text
kino-0.6.1/
    manifest.json
    p4.bin
    xiao.bin
    release-notes.md
    default-looks/
```

Manifest records product, supported hardware revisions, protocol/config ranges, file lengths, cryptographic hashes, signing information when implemented, required update order, and rollback compatibility.

Normal user flow is one button: **Update Kino**.

```text
validate package and power/storage state
→ upload package to P4 staging area
→ update camera nodes sequentially CAM1…CAM4
→ after each: verify image, reboot, ping, confirm version/health
→ update P4 last or in manifest-defined safe order
→ reboot and verify all five MCUs
→ migrate config transactionally
→ report success or rollback/recovery path
```

Studio must not ask normal users to select five binaries. The common XIAO binary is uploaded once to P4, then proxied to nodes. If a node fails, stop safely, keep successful nodes known, and do not blindly continue. Require sufficient battery or external power, but do not falsely promise safe charge-through operation.

Channels may later be Stable/Beta/Nightly; Nightly belongs behind Developer mode. P4 should use OTA rollback/known-working partitions. Camera nodes should preserve a known-working image where flash layout permits.

## 16. Recovery Center

Recovery is distinct from normal update:

- detect whether P4 application protocol responds;
- guide the user into P4 ROM/bootloader recovery and flash a validated recovery/main image;
- identify one failed camera node through the P4 proxy when possible;
- if proxy recovery is impossible, provide exact service-access instructions for directly connecting that XIAO’s USB-C;
- verify port identity, hardware revision, image hash, and post-flash health;
- never overwrite user media/config unless the selected recovery action requires it and the user confirms.

Recovery UI uses a step-by-step wizard with photos/diagrams tied to hardware revision. It should produce an exportable log for troubleshooting.

## 17. Security and integrity

- Firmware packages require hashes and should add signature verification before public release.
- Reject packages for the wrong product/hardware revision.
- Bound every serial length and validate every path/file ID.
- Do not allow media filenames to escape designated storage roots.
- Confirm destructive actions and make progress/cancel state explicit.
- Treat camera-provided text/metadata as data; escape it in the UI.
- Backups and looks include schema/compatibility declarations and checksums.

## 18. Visual direction

The Studio should evoke:

- Windows XP control panels and camera-transfer wizards;
- MSN Messenger friendliness and presence/status language;
- 2000s glossy icons, rounded blue/green panels, pixel accents, progress animations;
- playful labels such as “Kino is ready” and friendly camera-node avatars/status lights.

Avoid parody overload. The layout remains responsive, fast, keyboard-accessible, high-contrast where needed, and understandable without nostalgia. Advanced engineering detail is one click deeper; the home screen stays reassuring and simple.

## 19. Minimum viable Studio

1. Connect/disconnect and negotiate capabilities.
2. Show five-MCU health and versions.
3. Read/write versioned shooting configuration.
4. Configure Wiggle and Quad without reflashing.
5. Run camera-order and basic sensor/geometry calibration.
6. Browse a cursor-paginated gallery and download originals/metadata.
7. Display UART/capture timing diagnostics and export a log.
8. Install one validated firmware package through a unified update flow.
9. Offer documented P4 and direct-XIAO recovery paths.

Looks editor, browser animation rendering, resumable transfers, advanced flash calibration, and full skew visualization can follow once the end-to-end capture/update path is proven.
