# Kino V1 — Firmware, Capture, and Media Specification

## 1. Firmware topology

Kino V1 has one main firmware and one common camera-node firmware:

```text
P4 MAIN FIRMWARE
  UI • coordinator • storage • Studio protocol • renderer • updater
           │
           ├── XIAO CAMERA FIRMWARE, node ID CAM1
           ├── XIAO CAMERA FIRMWARE, node ID CAM2
           ├── XIAO CAMERA FIRMWARE, node ID CAM3
           └── XIAO CAMERA FIRMWARE, node ID CAM4
```

Do not create separate firmware images for Wiggle, Quad, Party, or film recipes. Modes and looks are configuration data. Firmware changes only when code/protocol behavior changes.

Each XIAO must support:

- sensor initialization and health report;
- capability/version response;
- preview JPEG generation when selected;
- exposure/gain/white-balance reporting and lock/application;
- `ARM`, shared-trigger response, capture, JPEG encoding;
- timing telemetry and error codes;
- chunked UART image transfer with integrity checks and retries;
- persistent node identity/calibration data;
- bootloader/update agent and post-update health check.

The P4 must support:

- camera discovery and physical/logical order mapping;
- mode/config/recipe management;
- exposure-master selection and distribution;
- shared flash/trigger sequencing;
- receipt and transactional storage of four images;
- rear UI, preview, review, gallery, and playback;
- metadata and diagnostics;
- USB Web Serial protocol and five-MCU update orchestration.

## 2. OV3660 starting configuration

| Setting | Wiggle default |
|---|---|
| Sensor | OV3660 |
| Resolution | **1600×1200** |
| HQ option | 2048×1536 |
| Aspect | 4:3 |
| Format | JPEG |
| JPEG quality | User-facing Normal/Fine; tune actual driver value empirically |
| XCLK | 20 MHz starting point |
| Frame buffers | PSRAM-backed; two where stable |
| Preview | 640×480 from one selected central-near node, normally CAM2 |
| Wi-Fi/BLE on XIAOs | Off while shooting |
| Denoise | Low |
| Sharpness | Moderate / approximately +1 starting point |
| Contrast | Approximately +1 starting point |
| Saturation | Approximately +1 starting point |
| HDR/computational cleanup | Off |

Exact driver numeric ranges and JPEG “quality” direction must be taken from the actual Espressif/Seeed driver revision. Store human-friendly values separately from hardware register values.

## 3. Wiggle capture cycle

```text
SHUTTER
  → verify all four nodes READY
  → sample/freeze master preview exposure, gain and white balance
  → distribute common settings + each node's small calibration offsets
  → send ARM to all four UARTs
  → wait for four ARMED acknowledgements or abort/degrade by policy
  → flash ON
  → wait calibrated pre-flash/settle delay
  → pulse shared SYNC_TRIGGER once
  → all nodes request/capture their active frame
  → collect capture/JPEG status
  → flash OFF
  → play shutter sound
  → transfer four completed JPEGs
  → write originals + metadata transactionally
  → render review/wiggle preview
```

Capture and transfer are distinct phases. The design goal is near-simultaneous capture; UART transfer may be sequential, interleaved, or parallel depending on measured stability and P4/SD buffering.

No shutter sound should occur during exposure because speaker vibration could affect the frame or feel of the device.

## 4. Exposure matching

Wiggle frames should differ primarily by viewpoint. A central-near preview node—normally CAM2—acts as exposure master. Immediately before the shot:

1. Freeze automatic exposure, gain, and white balance on the master.
2. Translate/distribute the master values to all nodes.
3. Apply small stored per-camera offsets for brightness and RGB matching.
4. Confirm the values were applied before `ARMED`.

Calibration should make the four images close enough that the animation does not flicker, but it should not sanitize every sensor difference. Preserve the physical camera’s cheap-digicam character.

## 5. Synchronization risk

The shared GPIO trigger is not true sensor frame synchronization. Four OV3660s can be in different free-running frame phases, and all are rolling-shutter devices. This creates two timing layers:

```text
P4 trigger edge
  → XIAO ISR/capture request skew      measurable in firmware/logic traces
  → OV3660 exposure/frame-row timing   must be measured optically or via VSYNC
```

Required development tests:

- logic-analyzer trigger vs. node ISR telemetry;
- observable VSYNC/frame-event logging if safely accessible;
- flashing LED/timecode panel in all four views;
- fast horizontal/vertical moving edge;
- hands, hair, glasses, drinks, and turning faces under flash;
- flash timing sweep to find a window that illuminates all four usable frames.

Metadata must distinguish `trigger_skew_reported_us` from any measured `exposure_skew_us`; never present the former as proof of the latter.

## 6. Flash strategy

The 3 W RA90 LED is a short direct-flash substitute:

- Auto / On / Off user modes;
- conservative starting current around 350 mA;
- pre-flash settle and total duration are calibration values;
- one pulse serves all cameras;
- default target distance 1–2 m;
- allow some clipped face highlights and dark backgrounds;
- shut off promptly after capture to control heat and power.

Auto mode can initially be simple: use preview exposure/gain and a calibrated threshold. Do not build an elaborate smartphone-style scene model.

## 7. Wiggle output

Default animation sequence:

```text
C1, C2, C3, C4, C3, C2
```

Settings:

- 10 fps default, adjustable 5–15 fps;
- bounce default; optional continuous/single sweep;
- left-to-right or reverse;
- automatic common-overlap crop, with preserve/custom options;
- geometry calibration corrects mount error only—it must not remove intended parallax.

Minimum V1 deliverables per shot:

- four original JPEGs;
- metadata JSON;
- on-device preview.

Preferred later deliverables:

- processed/look JPEGs;
- H.264 MP4 as primary share format;
- animated WebP;
- GIF for compatibility;
- contact sheet and ZIP bundle.

Animation creation may happen on P4 or in Kino Studio. Failure to generate an animation must never discard the original set.

## 8. Quad mode

Quad fires the same four-node hardware from one shutter but intentionally allows independent recipes and capture biases.

Per-camera fields may include:

- recipe ID/revision;
- exposure bias and gain ceiling;
- white-balance mode/offset;
- contrast, saturation, sharpness, denoise;
- flash participation;
- optional motion-safe shutter target where the sensor driver permits it.

Suggested preset sets:

- **Party Four:** Party Neg / Flash Digi / Motion / Acros-ish.
- **Film Four:** Chrome / Superia / Velvia-ish / Acros-ish.
- **Chaos:** four intentionally extreme recipes.
- **Raw Four:** minimal processing with slight exposure variations.

Quad uses the same universal firmware and saves all four originals. The rear display shows a 2×2 contact sheet after the shot.

## 9. Look engine

Looks are data packages, not firmware binaries. Suggested fields:

```json
{
  "lookSchema": 1,
  "id": "party-neg",
  "revision": 3,
  "name": "Party Neg",
  "capture": {},
  "tone": {},
  "color": {},
  "character": {}
}
```

Potential processing chain:

```text
JPEG decode
→ black/white levels
→ RGB matrix / temperature / tint
→ tone curve / gamma / highlight rolloff
→ saturation
→ optional grain/vignette/bloom/halation approximation/chromatic offset
→ JPEG encode
```

Character effects remain optional because much of Kino’s look should come from the physical sensors, lenses, direct light, and imperfect exposure. A future 17³ LUT representation is plausible; 33³ is better reserved for browser export where resources permit.

## 10. Storage layout and transactional behavior

```text
/DCIM/WG000042/
    C1_RAW.JPG
    C2_RAW.JPG
    C3_RAW.JPG
    C4_RAW.JPG
    C1_LOOK.JPG             optional
    C2_LOOK.JPG             optional
    C3_LOOK.JPG             optional
    C4_LOOK.JPG             optional
    WIGGLE.MP4              optional/derivative
    META.JSON
```

Write flow:

1. Reserve monotonically increasing capture ID.
2. Create temporary/incomplete directory marker.
3. Receive each JPEG in chunks with CRC and known length.
4. Flush and close each original.
5. Write metadata with per-file checksum/size/status.
6. Mark the set complete atomically where the filesystem permits.
7. Generate derivatives afterward.

On boot, recovery scans only incomplete markers/recent journal entries, not the entire gallery every time.

## 11. Metadata

Every capture set should include:

- capture ID and directory name;
- date/time and clock quality/source if available;
- mode and mode-profile revision;
- recipe IDs/revisions per camera;
- resolution, JPEG settings, exposure, gain, white balance;
- flash mode, requested level/current setting, settle/duration;
- battery voltage before/during/after, where measured;
- P4, C6, and four XIAO firmware/protocol versions;
- hardware revision and camera serial/node IDs;
- physical camera order and lens-center positions;
- calibration ID/revision/checksum;
- P4 trigger time, node ISR time, sensor/frame timing if available;
- arm, capture, encode, transfer, and save durations;
- per-file byte length and checksum;
- error/retry/degraded-capture flags.

Metadata schema must be versioned and forward-readable by Studio.

## 12. UART transport strategy

Recommended control/data split on each UART:

- length-prefixed binary frames;
- message type, protocol version, node ID, request/capture ID, payload length;
- header CRC plus payload CRC32;
- small JSON/CBOR-like control payloads or fixed binary structures;
- binary JPEG chunks without base64;
- acknowledgement, timeout, retry, cancel, and resume-from-offset support.

At 921,600 baud, large JPEGs take meaningful time. Keep preview modest, capture locally into PSRAM, and avoid transmitting any full-resolution image until all nodes have completed the shot. Evaluate higher baud only with repeated integrity testing in the final harness geometry.

## 13. Camera UI

Keep the on-device UI simple:

```text
┌────────────────────────────┐
│ WIGGLE     PARTY NEG    2M │
│                            │
│          PREVIEW           │
│                            │
│ FLASH ON              0042 │
└────────────────────────────┘
```

Normal controls:

- Wiggle / Quad;
- look/profile;
- Flash Auto / On / Off;
- 2M / 3M;
- gallery/playback;
- battery bars and storage warning.

Avoid live histograms, AI labels, HDR indicators, and dense settings. Advanced work belongs in Kino Studio.

## 14. Failure behavior

- A node that fails `ARM` cancels Wiggle by default; optionally allow a clearly marked degraded set in developer mode.
- Flash must turn off on timeout or crash via hardware-default-off design.
- Partial UART transfer retries from a safe chunk boundary.
- SD failure preserves node buffers as long as practical and reports recovery options.
- Never overwrite a valid prior capture ID.
- Brownout/reset causes an explicit incomplete set rather than silent corruption.
- Version mismatch blocks unsafe configuration/update combinations but still exposes recovery diagnostics.

## 15. V2 upgrade path

V2 retains Studio, mode/config schemas, four-node abstraction, shot IDs, calibration concepts, gallery, metadata, and update orchestration. It replaces:

- OV3660/DVP with ~12 MP MIPI sensors;
- XIAO-S3 camera heads with MIPI/ISP-capable processors or custom P4-class boards;
- best-effort GPIO triggering with shared hardware frame sync;
- UART image transport with USB HS or another high-speed link;
- V1 power stage with a system sized for four larger camera pipelines.

IMX477/XVS is the current conceptual reference, not a purchased V2 decision. A future “Digi” mode should optionally downsample/high-compress the 12 MP image to approximately 3 MP with V1-like tone while retaining V2 synchronization and crop margin.
